import React from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import Link from "next/link";

const DashCard = ({
  title,
  Description,
  Content,
  goto,
  linkhref = "",
  Footer,
}: {
  title: string;
  Description: string;
  Content: string;
  goto: string;
  linkhref: string;
  Footer: string;
}) => {
  return (
    <Card className="flex flex-col w-full">
      <CardHeader>
        <CardTitle className="text-2xl text-red-500 dark:text-white">
          {title}
        </CardTitle>
        <CardDescription> {Description}</CardDescription>
      </CardHeader>
      <CardContent>
        <div>
          <p>{Content}</p>
          <Link href={linkhref} className="text-blue-600">
            {goto}
          </Link>
        </div>
      </CardContent>
      <CardFooter>
        <p>{Footer}</p>
      </CardFooter>
    </Card>
  );
};

export default DashCard;
