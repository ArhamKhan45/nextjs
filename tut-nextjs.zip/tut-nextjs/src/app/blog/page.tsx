import Link from "next/link";
import React from "react";

const Blog = () => {
  return (
    <div>
      <h1> I am a blog page</h1>
      <Link
        href={"/blog/first"}
        className="mr-3
      "
      >
        {" "}
        First{" "}
      </Link>
      <Link
        href={"/blog/second"}
        className="mr-3
      "
      >
        {" "}
        Second
      </Link>
    </div>
  );
};

export default Blog;
