import Link from "next/link";
import React from "react";

const FirstBlog = () => {
  return (
    <div>
      <h1> I am a First blog page</h1>
    </div>
  );
};

export default FirstBlog;
