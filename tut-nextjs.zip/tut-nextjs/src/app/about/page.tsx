"use client";
import { useRouter } from "next/navigation";
import React from "react";

const About = () => {
  const router = useRouter();

  const gotohome = () => {
    return router.push("/home", { scroll: false });
  };

  return (
    <div>
      <h1>About us page</h1>
      <button
        onClick={gotohome}
        className="text-yellow-50 bg-neutral-500 hover:bg-blue-700  font-bold py-2 px-4 focus:outline-none focus:ring focus:ring-blue-300 "
      >
        home
      </button>
    </div>
  );
};

export default About;
