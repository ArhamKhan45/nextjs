"use client";
import React, { useState } from "react";

const TempTemplate = ({ children }: { children: React.ReactNode }) => {
  const [count, setcount] = useState(0);
  return (
    <>
      <h1>This is the template template</h1>
      <button
        onClick={() => setcount(count + 1)}
        className="px-5 py-1 bg-blue-600 text-white mr-2 focus:ring rounded-lg  "
      >
        Count-{count}
      </button>

      <button className="bg-blue-600 hover:bg-lime-400 active:bg-blue-500 mr-2 text-white font-bold py-2 px-4 rounded">
        Click Me
      </button>
      <input type="text" name="" id="" className="border-2 border-red-500" />
      {children}
    </>
  );
};

export default TempTemplate;
