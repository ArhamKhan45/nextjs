import Link from "next/link";
import React from "react";

const Tempcheck = () => {
  return (
    <div>
      <div>
        <Link href={"/tempcheck/checktoo"} className="text-blue-700">
          check too
        </Link>
      </div>
      this is for template.tsx
    </div>
  );
};

export default Tempcheck;
