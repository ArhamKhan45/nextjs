"use client";
import React, { useState } from "react";

const Templayout = ({ children }: { children: React.ReactNode }) => {
  const [count, setcount] = useState(0);
  return (
    <>
      <h1>This is the temp layout</h1>
      {children}
    </>
  );
};

export default Templayout;
