import React from "react";

const Checktoo = () => {
  return <div>check to hu</div>;
};

export default Checktoo;
