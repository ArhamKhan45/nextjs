import React from "react";

const product = ({ params }: { params: { productId: string } }) => {
  return (
    <div>
      <p>I m a product {params.productId} page</p>
    </div>
  );
};

export default product;
