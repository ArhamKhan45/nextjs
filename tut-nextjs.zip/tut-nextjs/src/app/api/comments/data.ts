export const comments = [
  {
    id: 1,
    text: "this is the first comment",
  },
  {
    id: 2,
    text: "this is the second comment",
  },
  {
    id: 3,
    text: "this is the third comment",
  },
];
