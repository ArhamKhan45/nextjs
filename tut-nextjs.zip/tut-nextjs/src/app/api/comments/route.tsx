import { NextRequest } from "next/server";
import { comments } from "./data";

export const GET = async () => {
  return Response.json(comments);
};

export const POST = async (req: NextRequest) => {
  const comment = await req.json();

  // if (!comment.text) {
  //   console.log(comment);
  //   return Response.json(
  //     {
  //       success: false,
  //       message: "data not found",
  //     },
  //     {
  //       headers: { "Content-Type": "application/json" },
  //       status: 201,
  //     }
  //   );
  // }

  const newComment = {
    id: comments.length + 1,
    text: comment.text,
  };
  comments.push(newComment);
  return Response.json(
    {
      success: true,
      comment: newComment,
    },

    {
      headers: { "Content-Type": "application/json" },
      status: 201,
    }
  );
};

// \
// {
//   "text": "this is the fourth comment"
// }
