const Homepage = () => {
  return <div>i m a home Page</div>;
};

export default Homepage;
