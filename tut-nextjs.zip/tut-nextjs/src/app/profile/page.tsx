import React from "react";

const Profile = () => {
  const getRandomInt = (count: number): number => {
    return Math.floor(count * Math.random());
  };

  const value = getRandomInt(2);

  if (value === 1) {
    throw new Error("Invalid value: error loading  " + value);
  }
  return (
    <div>
      <h1>I m a profile page</h1>
      <p>{value}</p>
    </div>
  );
};

export default Profile;
