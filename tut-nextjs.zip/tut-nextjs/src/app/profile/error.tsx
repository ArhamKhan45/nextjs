"use client";
import React from "react";

const ErrorBoundary = ({
  error,
  reset,
}: {
  error: Error;
  reset: () => void;
}) => {
  return (
    <div>
      <p>error in profile page {error.message}</p>
      <button
        onClick={reset}
        className="bg-blue-600 text-zinc-100 px-2 rounded-sm"
      >
        reload
      </button>
    </div>
  );
};

export default ErrorBoundary;
