import Link from "next/link";
import React from "react";

const ArchivedNotification = () => {
  return (
    <div>
      <div>
        <p>
          Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ipsa a
          voluptate maiores aperiam corrupti! Temporibus deserunt, tenetur modi
          provident ab consequuntur repellat expedita cumque, itaque a possimus
          odio mollitia aliquam.
        </p>
      </div>
      <Link href={"/dashboard/"} className="text-blue-600">
        Default Notifications
      </Link>
    </div>
  );
};

export default ArchivedNotification;
