import DashCard from "@/utils/DashCard";
import Link from "next/link";

export default function DashNotification() {
  const describe: string =
    "Lorem ipsum dolor, sit amet consectetur adipisicing elit. Error eligendi aspernatur soluta, aut voluptates, possimus ex non, a sunt maiores consequuntur dignissimos. Non itaque velit iure expedita, minus voluptates fuga?";

  return (
    <>
      <DashCard
        title={"Dashboard Notification"}
        Description={describe}
        Content="Arham khan"
        goto="Archieved Notification"
        linkhref="/dashboard/archieve"
        Footer="submitted"
      />
    </>
  );
}
