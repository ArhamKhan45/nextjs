// slots are available as props in the layout

export default function DashboardLayout({
  children,
  analytics,
  awards,
  reports,
  notifications,
  login,
}: {
  children: React.ReactNode;
  analytics: React.ReactNode;
  awards: React.ReactNode;
  reports: React.ReactNode;
  notifications: React.ReactNode;
  login: React.ReactNode;
}) {
  const isLoggedIn: Boolean = false;

  return isLoggedIn ? (
    <div className="flex flex-row flex-wrap h-auto w-full">
      <div className="w-full">{children}</div>
      <div className="w-1/4">{analytics}</div>
      <div className="w-1/4">{awards}</div>
      <div className="w-1/4">{reports}</div>
      <div className="w-1/4">{notifications}</div>
    </div>
  ) : (
    <div>
      <div className="w-1/4">{login}</div>
    </div>
  );
}
