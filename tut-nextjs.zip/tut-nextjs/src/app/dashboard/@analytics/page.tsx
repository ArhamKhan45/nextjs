import DashCard from "@/utils/DashCard";

export default function UsersAnalytics() {
  const describe: string =
    "Lorem ipsum dolor, sit amet consectetur adipisicing elit. Error eligendi aspernatur soluta, aut voluptates, possimus ex non, a sunt maiores consequuntur dignissimos. Non itaque velit iure expedita, minus voluptates fuga?";

  return (
    <DashCard
      title={"Users Analytics"}
      Description={describe}
      Content="Arham khan"
      Footer="submitted"
    />
  );
}
