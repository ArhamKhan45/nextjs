import React from "react";

const DefaultDashboard = () => {
  return (
    <div>
      <p>Section Under Development</p>
    </div>
  );
};

export default DefaultDashboard;
