import React from "react";

const Dashboard = () => {
  return (
    <div>
      <h1 className="text-3xl w-full">The Dashboard hu</h1>
    </div>
  );
};

export default Dashboard;
