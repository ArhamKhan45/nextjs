import React from "react";

const LoadingComponent = () => {
  return (
    <div>
      <h1>Loading...</h1>
    </div>
  );
};

export default LoadingComponent;
