import React from "react";

const DefaultDashboard = () => {
  return (
    <div>
      <p>The Dashboard helloooo</p>
    </div>
  );
};

export default DefaultDashboard;
