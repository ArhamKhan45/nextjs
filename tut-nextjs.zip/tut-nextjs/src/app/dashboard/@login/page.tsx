import React from "react";

const LoginDashboard = () => {
  return (
    <div>
      <p>Please login to Access the dashboard</p>
    </div>
  );
};

export default LoginDashboard;
