import { Button } from "@/components/ui/button";
import Image from "next/image";
import Homepage from "./home/page";

export default function Home() {
  return (
    <div>
      <h1> Home Page</h1>
      <Button>Click me</Button>
      <Homepage />
    </div>
  );
}
