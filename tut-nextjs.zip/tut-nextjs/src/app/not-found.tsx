"use client";
import { useRouter } from "next/navigation";
import React from "react";

const NotFoundPage = () => {
  const router = useRouter();
  function bgColorHandler() {
    document.body.style.backgroundColor = "green ";
  }
  return (
    <div>
      <h1 className="text-4xl font-bold"> Page not found</h1>

      <button
        className="py-1 px-2 rounded-sm bg-red-700 m-3 text-white hover:bg-red-500 focus:ring "
        onClick={() => router.push("/")}
      >
        Home
      </button>
      <button
        className="p-3 bg-red-700 m-3 text-white hover:bg-red-500 focus:ring "
        onClick={() => router.refresh()}
      >
        Refresh The page
      </button>
      <button
        className="p-3 bg-red-700 m-3 text-white hover:bg-red-500 focus:ring "
        onClick={() => router.forward()}
      >
        go back to last page
      </button>
      <button
        className="p-3 bg-red-700 m-3 text-white hover:bg-red-500 focus:ring "
        onClick={() => bgColorHandler()}
      >
        go green
      </button>
    </div>
  );
};

export default NotFoundPage;
