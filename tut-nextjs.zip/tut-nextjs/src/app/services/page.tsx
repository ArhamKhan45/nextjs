import React from "react";

const Services = () => {
  return <div>I m service</div>;
};

export default Services;
