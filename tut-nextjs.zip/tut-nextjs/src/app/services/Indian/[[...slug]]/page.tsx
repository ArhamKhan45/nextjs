import React from "react";

const Indian = () => {
  return <div>I m Indian</div>;
};

export default Indian;
