import React from "react";
import {
  MdDashboard,
  MdSupervisedUserCircle,
  MdShoppingBag,
  MdAttachMoney,
  MdWork,
  MdAnalytics,
  MdPeople,
  MdOutlineSettings,
  MdHelpCenter,
  MdLogout,
} from "react-icons/md";
import MenuLink from "./menuLink/menuLink";
import Style from "./sidebar.module.css";
import Image from "next/image";
interface list {
  title: string;
  path: string;
  icon: React.ReactNode;
}
interface menuItems {
  title: string;
  list: list[];
}
const Sidebar = () => {
  const menuItems: menuItems[] = [
    {
      title: "Pages",
      list: [
        {
          title: "Dashboard",
          path: "/dashboard",
          icon: <MdDashboard />,
        },
        {
          title: "Users",
          path: "/users",
          icon: <MdSupervisedUserCircle />,
        },
        {
          title: "Products",
          path: "/products",
          icon: <MdShoppingBag />,
        },
        {
          title: "Transactions",
          path: "/transactions",
          icon: <MdAttachMoney />,
        },
      ],
    },
    {
      title: "Analytics",
      list: [
        {
          title: "Revenue",
          path: "/revenue",
          icon: <MdWork />,
        },
        {
          title: "Reports",
          path: "/reports",
          icon: <MdAnalytics />,
        },
        {
          title: "Teams",
          path: "/teams",
          icon: <MdPeople />,
        },
      ],
    },
    {
      title: "User",
      list: [
        {
          title: "Settings",
          path: "/settings",
          icon: <MdOutlineSettings />,
        },
        {
          title: "Help",
          path: "/help",
          icon: <MdHelpCenter />,
        },
      ],
    },
  ];

  return (
    <div className={Style.container}>
      <div className={Style.user}>
        <Image
          src={"" || "/noavatar.png"}
          className={Style.userimg}
          alt=""
          width="45"
          height="45"
        />
        <div className={Style.userDetail}>
          <span className={Style.username}>admin</span>
          <span className={Style.userTitle}>Adminstrator</span>
        </div>
      </div>
      <ul className={Style.list}>
        {menuItems.map((item, index) => {
          return (
            <li key={index} className={""}>
              <span className={Style.item}>{item.title}</span>
              {item.list.map((innerItem, index) => (
                <MenuLink item={innerItem} key={index} />
              ))}
            </li>
          );
        })}
      </ul>
      <button className={Style.logout}>
        <MdLogout />
        Logout
      </button>
    </div>
  );
};

export default Sidebar;
