import { MdSupervisedUserCircle } from "react-icons/md";
import Style from "./card.module.css";
const Card = () => {
  return (
    <div className={Style.container}>
      <MdSupervisedUserCircle size={24} />
      <div className={Style.texts}>
        <span className={Style.title}>Total user</span>
        <span className={Style.number}>98.555</span>
        <span className={Style.detail}>
          <span className={Style.positive}>12% </span>than previous week
        </span>
      </div>
    </div>
  );
};

export default Card;
