import React from "react";

const LoginForm = () => {
  return (
    <div>
      <h2>Login Form</h2>
    </div>
  );
};

export default LoginForm;
