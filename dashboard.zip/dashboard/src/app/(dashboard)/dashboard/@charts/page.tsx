import Chart from "@/customui/dashboard/chart/chart";

const ChartDetails = () => {
  return (
    <div className={""}>
      <Chart />
    </div>
  );
};

export default ChartDetails;
