const Defaultchart = () => {
  return <div> site is under development</div>;
};

export default Defaultchart;
