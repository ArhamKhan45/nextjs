import Card from "@/customui/dashboard/card/card";
import Style from "./card.module.css";
const CardDetails = () => {
  return (
    <div className={Style.container}>
      <Card />
      <Card />
      <Card />
    </div>
  );
};

export default CardDetails;
