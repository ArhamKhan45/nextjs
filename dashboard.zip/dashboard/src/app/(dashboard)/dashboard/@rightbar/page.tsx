import RightBar from "@/customui/dashboard/rightbar/rightbar";

const RightbarDetails = () => {
  return (
    <div className={""}>
      <RightBar />
    </div>
  );
};

export default RightbarDetails;
