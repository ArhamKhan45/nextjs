const DefaultTransactions = () => {
  return <div> site is under development</div>;
};

export default DefaultTransactions;
