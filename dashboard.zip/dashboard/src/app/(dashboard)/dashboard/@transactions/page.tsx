import Transactions from "@/customui/dashboard/transactions/transactions";

const TransactionsDetails = () => {
  return (
    <div className={""}>
      <Transactions />
    </div>
  );
};

export default TransactionsDetails;
